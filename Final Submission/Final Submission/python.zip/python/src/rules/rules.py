from datetime import datetime
class Rules:
    """
    Rules class for logical decision
    """
    __instance = None

    @staticmethod
    def get_instance():
        """ Static access method. """
        if Rules.__instance == None:
            Rules()
        return Rules.__instance

    def __init__(self):
        if Rules.__instance != None:
            raise Exception("This class is a singleton!")
        else:
            Rules.__instance = self

    """ 
    This function will check credit score and return False if it is less than 200 else returns True 
    """
    def checkScore(self, score):
        if int(score) < 200:
            return False
        else:
            return True

    """ 
        This function will calculate speed based on time and distance between two recent transactions
        and return False if speed is greater than 0.25km/s else returns True 
    """
    def checkSpeed(self, last_transaction_date, current_transaction_date, distance):
        curts = datetime.strptime(current_transaction_date, '%d-%m-%Y %H:%M:%S')
        lasts = datetime.strptime(last_transaction_date, '%d-%m-%Y %H:%M:%S')
        timeinterval = (curts - lasts).total_seconds()
        speed = distance / timeinterval
        if (speed > 0.25):
            return False
        else:
            return True

    """ 
        This function will compare the ucl and the transaction amount
        and return False if amount is greater than ucl else returns True 
    """
    def checkUcl(self, amount, ucl):
        if amount > int(ucl):
            return False
        else:
            return True