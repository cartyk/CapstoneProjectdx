# importing necessary libraries
import os
import sys
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import *
import uuid


# initialising Spark session
spark = SparkSession \
    .builder \
    .appName("spark-streaming") \
    .getOrCreate()
spark.sparkContext.setLogLevel('ERROR')


# adding required python files
spark.sparkContext.addPyFile('db/dao.py')
spark.sparkContext.addPyFile('db/geo_map.py')
spark.sparkContext.addPyFile('rules/rules.py')

# importing modules from python files
from dao import *
from geo_map import *
from rules import *

# defining schema for a single order
jsonSchema = StructType() \
    .add("card_id", StringType()) \
    .add("member_id", StringType()) \
    .add("amount", LongType()) \
    .add("postcode", StringType()) \
    .add("pos_id", StringType()) \
    .add("transaction_dt", StringType())

# reading input from Kafka
orderRawData = spark.readStream \
    .format("kafka") \
    .option("kafka.bootstrap.servers", "18.211.252.152:9092") \
    .option("startingOffsets", "earliest") \
    .option("failOnDataLoss", "false") \
    .option("subscribe", "transactions-topic-verified") \
    .load()

# creating an order stream for reading data from json in kafka
orderStream = orderRawData.select(from_json(col("value").cast("string"), jsonSchema).alias("data")).select("data.*")


# Define function to get data from hbase lookup table for given card_id
def getData(card_id):
    lookupdata = HBaseDao.get_instance().get_data(card_id, 'lookup_hbase')
    dic = {}
    for x in lookupdata:
        dic[x.decode()] = lookupdata[x].decode()
    return dic

# Define function to get distance between two postcodes of recent transaction
def distance(currentPostcode, lookupdata):
    oldPostcode = lookupdata['lookup_column_family:postcode']
    return GEO_Map.get_instance().distance(GEO_Map.get_instance().get_lat(currentPostcode),GEO_Map.get_instance().get_long(currentPostcode),GEO_Map.get_instance().get_lat(oldPostcode),GEO_Map.get_instance().get_long(oldPostcode))

# Define function to determine status of transaction
def determineTransaction(current_transaction_date, distance, amount, lookupdata):
    if (Rules.get_instance().checkScore(lookupdata['lookup_column_family:score']) and Rules.get_instance().checkUcl(amount, lookupdata['lookup_column_family:ucl']) and Rules.get_instance().checkSpeed(lookupdata['lookup_column_family:transaction_dt'], current_transaction_date, distance)):
        return "GENUINE"
    else:
        return "FRAUD"

# Define function to add transaction record to card_transactions table
def dataForTransaction(card_id, member_id, amount, postcode, pos_id, transaction_dt, status):
    row = {}
    key1 = "ctf:card_id"
    key2 = "ctf:member_id"
    key3 = "ctf:amount"
    key4 = "ctf:postcode"
    key5 = "ctf:pos_id"
    key6 = "ctf:transaction_dt"
    key7 = "ctf:status"

    row[key1.encode()] = str(card_id).encode()
    row[key2.encode()] = str(member_id).encode()
    row[key3.encode()] = str(amount).encode()
    row[key4.encode()] = str(postcode).encode()
    row[key5.encode()] = str(pos_id).encode()
    row[key6.encode()] = str(transaction_dt).encode()
    row[key7.encode()] = str(status).encode()
    HBaseDao.get_instance().write_data(str(uuid.uuid1()).encode(), row, 'card_transactions')
    return "OK"

# Define function to add genuine transaction record to lookup table
def dataForLookup(key, current_transaction_date, postcode):
    row = {}
    key1 = "lookup_column_family:transaction_dt"
    key2 = "lookup_column_family:postcode"
    row[key1.encode()] = str(current_transaction_date).encode()
    row[key2.encode()] = str(postcode).encode()
    HBaseDao.get_instance().write_data(key.encode(), row, 'lookup_hbase')
    return "OK"


# creating UDFs of functions to use in pyspark
getDataUDF = udf(lambda x : getData(x), MapType(StringType(), StringType()))
distanceUDF = udf(lambda x,y : distance(x,y), FloatType())
determineTransactionUDF = udf(lambda x,y,z,w : determineTransaction(x,y,z,w))
dataForLookupUDF = udf(lambda x,y,z : dataForLookup(x,y,z))
dataForTransactionUDF = udf(lambda x,y,z,w,l,m,n : dataForTransaction(x,y,z,w,l,m,n))



df2 = orderStream.withColumn("lookupData", getDataUDF(orderStream.card_id))
df3 = df2.withColumn("distance", distanceUDF(df2.postcode, df2.lookupData))
df4 = df3.withColumn("flag", determineTransactionUDF(df3.transaction_dt, df3.distance, df3.amount, df3.lookupData))
df5 = df4.withColumn("transactionResult", dataForTransactionUDF(df4.card_id, df4.member_id, df4.amount,df4.postcode, df4.pos_id, df4.transaction_dt, df4.flag))
df6 = df4.filter(col("flag") == "GENUINE").withColumn("lookupResult", dataForLookupUDF(df4.card_id, df4.transaction_dt, df4.postcode))

query0 = df5 \
    .select("card_id","member_id","amount","pos_id","postcode","transaction_dt","flag") \
    .writeStream \
    .outputMode("append") \
    .format("console") \
    .option("truncate", "false") \
    .trigger(processingTime="1 minute") \
    .start()


query1 = df5 \
    .select("*") \
    .writeStream \
    .outputMode("append") \
    .format("json") \
    .option("format", "append") \
    .option("truncate", "false") \
    .option("path", "card_transactions_records") \
    .option("checkpointLocation", "card_transactions_records_checkpoint") \
    .option("truncate", "False") \
    .trigger(processingTime="1 minute") \
    .start()



query2 = df6 \
    .select("*") \
    .writeStream \
    .outputMode("append") \
    .format("json") \
    .option("format", "append") \
    .option("truncate", "false") \
    .option("path", "lookup_hbase_records") \
    .option("checkpointLocation", "lookup_hbase_records_checkpoint") \
    .option("truncate", "False") \
    .trigger(processingTime="1 minute") \
    .start()

# indicating Spark to await termination
query0.awaitTermination()
query1.awaitTermination()
query2.awaitTermination()

